﻿using System;

namespace Sansula_Kalimba
{
	public class Instrument
	{
		public Instrument ()
		{
		}
	}
}

