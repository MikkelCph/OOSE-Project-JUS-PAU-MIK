﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Media;


namespace Sansula_Kalimba
{
	[Activity (Label = "PlayPage")]			
	public class PlayPage : Activity
	{
		MediaPlayer _player;
		MediaPlayer _player2;
		MediaPlayer _player3;
		MediaPlayer _player4;
		MediaPlayer _player5;
		MediaPlayer _player6;
		MediaPlayer _player7;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.Play);

			_player = MediaPlayer.Create (this, Resource.Raw.vienas);
			_player2 = MediaPlayer.Create (this, Resource.Raw.du);
			_player3 = MediaPlayer.Create (this, Resource.Raw.trys);
			_player4 = MediaPlayer.Create (this, Resource.Raw.keturi);
			_player5 = MediaPlayer.Create (this, Resource.Raw.penki);
			_player6 = MediaPlayer.Create (this, Resource.Raw.sesi);
			_player7 = MediaPlayer.Create (this, Resource.Raw.septyni);



			var sound1 = FindViewById<Button> (Resource.Id.sound1);
			var sound2 = FindViewById<Button> (Resource.Id.sound2);
			var sound3 = FindViewById<Button> (Resource.Id.sound3);
			var sound4 = FindViewById<Button> (Resource.Id.sound4);
			var sound5 = FindViewById<Button> (Resource.Id.sound5);
			var sound6 = FindViewById<Button> (Resource.Id.sound6);
			var sound7 = FindViewById<Button> (Resource.Id.sound7);



			sound1.Click += delegate {

				PlayThisSound (_player);
			};

			sound2.Click += delegate {
			
				PlayThisSound (_player2);
			};

			sound3.Click += delegate {

				PlayThisSound (_player3);
			};

			sound4.Click += delegate {
			
				PlayThisSound (_player4);
			};

			sound5.Click += delegate {
			
				PlayThisSound (_player5);
			};
			sound6.Click += delegate {

				PlayThisSound (_player6);
			};
			sound7.Click += delegate {
			
				PlayThisSound (_player7);
			};

		}

		private void PlayThisSound (MediaPlayer sound)
		{
				sound.Stop ();
				sound.Prepare ();
				sound.Start ();

		}

		private void StopSounds ()
		{
			_player.Stop ();
			_player2.Stop ();
			_player3.Stop ();
			_player4.Stop ();
			_player5.Stop ();
		}


		}
	}

