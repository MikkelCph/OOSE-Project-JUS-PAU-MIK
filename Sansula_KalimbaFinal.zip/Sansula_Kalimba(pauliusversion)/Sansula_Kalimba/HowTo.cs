﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;

namespace Sansula_Kalimba
{
	// we just define the activity class, set the label and the screen orientation is set to only the portrait
	[Activity (Label = "HowTo", ConfigurationChanges = ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Portrait)]			
	public class HowTo : Activity
	{
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			//with two lines below we make the activity to be a fullscreen
			RequestWindowFeature (WindowFeatures.NoTitle);
			Window.SetFlags (WindowManagerFlags.Fullscreen, WindowManagerFlags.Fullscreen);
			//we set the layout to be a HowToPlay layout under the Resource/layout folder
			SetContentView (Resource.Layout.Howtoplay);

		}
	}
}

