﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Content.PM;
using Android.Media;


namespace Sansula_Kalimba
{
	// we just define the activity class, set the label and the screen orientation is set to only the portrait
	[Activity (Label = "Sansula", MainLauncher = true, ConfigurationChanges = ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Portrait)]

	public class MainActivity : Activity
	{


		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			//with two lines below we make the main activity to be fullscreen
			RequestWindowFeature (WindowFeatures.NoTitle);
			Window.SetFlags (WindowManagerFlags.Fullscreen, WindowManagerFlags.Fullscreen);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);


			//we create two button variables and attach them to the buttons created in the Main layout
			var showPlay = FindViewById<Button> (Resource.Id.Play);
			var showHow = FindViewById<Button> (Resource.Id.HowTo);
			//over here we attach the events to the buttons created above
			var instrument = new Intent(this, typeof(PlayPage));
			var howTo = new Intent(this, typeof(HowTo));


			//these two functions declare what is going to happen when one of the buttons are clicked (both of them going to open two different pages, either Playpage or HowTo)
			showPlay.Click += delegate {

				StartActivity(instrument);
				//button_play.Text = string.Format ("{0} clicks!", count++);
			};
				

			showHow.Click += delegate {

				StartActivity(howTo);
				//button_how.Text = string.Format ("{0} clicks!", count++);
			};

		}
	}
}


