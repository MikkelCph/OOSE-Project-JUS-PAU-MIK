﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Media;
using Android.Content.PM;


namespace Sansula_Kalimba
{
	// we just define the activity class, set the label and the screen orientation is set to only the landscape
	[Activity (Label = "PlayPage", ConfigurationChanges = ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Landscape)]
	//the start of activity class
	public class PlayPage : Activity
	{
		//we create 7 mediaplayers which will play 7 different sounds in our music instrument
		MediaPlayer _player;
		MediaPlayer _player2;
		MediaPlayer _player3;
		MediaPlayer _player4;
		MediaPlayer _player5;
		MediaPlayer _player6;
		MediaPlayer _player7;


		//OnCreate class starts
		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);
			// with two lines below we make this activity fullscreen, meaning that the bar with battery and time will not be visible when opening this activity
			RequestWindowFeature (WindowFeatures.NoTitle);
			Window.SetFlags (WindowManagerFlags.Fullscreen, WindowManagerFlags.Fullscreen);

			//we set the layout for this activity, and we set it to be a layout named Play under Resource/Layout folder
			SetContentView (Resource.Layout.Play);

			//for all the 7 mediaplayers that we created above we assign one sound for each. The sounds are found under the Resource/raw folder
			_player = MediaPlayer.Create (this, Resource.Raw.vienas);
			_player2 = MediaPlayer.Create (this, Resource.Raw.du);
			_player3 = MediaPlayer.Create (this, Resource.Raw.trys);
			_player4 = MediaPlayer.Create (this, Resource.Raw.keturi);
			_player5 = MediaPlayer.Create (this, Resource.Raw.penki);
			_player6 = MediaPlayer.Create (this, Resource.Raw.sesi);
			_player7 = MediaPlayer.Create (this, Resource.Raw.septyni);


			// over here we create 7 different button variables and we assign buttons created in Play layout and named sound1-7
			var sound1 = FindViewById<Button> (Resource.Id.sound1);
			var sound2 = FindViewById<Button> (Resource.Id.sound2);
			var sound3 = FindViewById<Button> (Resource.Id.sound3);
			var sound4 = FindViewById<Button> (Resource.Id.sound4);
			var sound5 = FindViewById<Button> (Resource.Id.sound5);
			var sound6 = FindViewById<Button> (Resource.Id.sound6);
			var sound7 = FindViewById<Button> (Resource.Id.sound7);


			// 7 same functions for different buttons, when button is clicked, the PlayThisSound() function is called with the input variable _player1-7
			sound1.Click += delegate {

				PlayThisSound (_player);
			};

			sound2.Click += delegate {
			
				PlayThisSound (_player2);
			};

			sound3.Click += delegate {

				PlayThisSound (_player3);
			};

			sound4.Click += delegate {
			
				PlayThisSound (_player4);
			};

			sound5.Click += delegate {
			
				PlayThisSound (_player5);
			};
			sound6.Click += delegate {

				PlayThisSound (_player6);
			};
			sound7.Click += delegate {
			
				PlayThisSound (_player7);
			};

		}

		//the PlayThisSound idea is to Stop the particular sound that was playing and then start it over again
		private void PlayThisSound (MediaPlayer sound)
		{
				sound.Stop ();
				sound.Prepare ();
				sound.Start ();

		}
		//StopSounds() function stops all the activated sounds
		private void StopSounds ()
		{
			_player.Stop ();
			_player2.Stop ();
			_player3.Stop ();
			_player4.Stop ();
			_player5.Stop ();
			_player6.Stop ();
			_player7.Stop ();
		}


		}
	}

